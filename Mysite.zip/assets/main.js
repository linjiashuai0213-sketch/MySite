/* ── Project Data ─────────────────────────────────────── */
const PROJECTS = {
  'real-estate': {
    num:    '01',
    title:  '资金计划 2.0',
    client: '某知名全国性房地产集团（行业 TOP5）',
    role:   '产品经理',
    period: '2020.06 — 2020.11',
    tags:   ['IBM TM1', '元年 TaBase', '多维数据库', '资金管理', '投融资计划'],
    overview:
      '将集团原有定制化开发的资金计划 1.0 系统进行完全重构，使用基于 IBM TM1 多维数据库的元年 TaBase 作为底层数据库进行设计与开发。' +
      '涉及整个集团所有区域及项目的投融资计划、资金预测、资金分析、资金预警等核心功能。',
    achievements: [
      '成功推进项目上线，在功能、性能、用户体验及数据准确性上均有飞跃式提升',
      '管理 20+ 人项目实施团队，统筹从方案设计、实施开发到 UAT 测试全流程',
      '重构后系统实现投融资全链路在线管理，大幅提升集团资金管控效率',
    ]
  },
  'insurance': {
    num:    '02',
    title:  '投资管理系统',
    client: '某国内顶级寿险集团旗下健康投资公司',
    role:   '项目经理 / 主管',
    period: '2020.11 — 2022.10',
    tags:   ['先胜业财 Seepln', '投资全周期管理', '全面预算', '健康产业', '业财连接'],
    overview:
      '包含两大子项目：\n\n' +
      '① 投资模型项目：打造养康投资项目投前、投中、投后全周期管理平台，建立数据与系统贯通的投资-规划-预算新业务形态，形成业务闭环和数据反馈机制。\n\n' +
      '② 全面预算项目：实现养老社区、康复医院和纪念园从预算到执行、投资、规划的项目管理闭环，加强预算版本管理，统一数据口径。',
    achievements: [
      '两个百万级项目，投资模型项目将 30+ 在投项目维护至系统，完成 20+ 新投资项目各版本在线投前测算',
      '全面预算项目打通从投资到规划到预算到闭环的完整策略，历时 6 个月',
      '涉及 3 大主营业态（养老社区、康复医院、纪念园），50+ 编制单位，200+ 用户',
      '提升各事业部及总部的预算填报及审批效率',
    ]
  },
  'photovoltaic': {
    num:    '03',
    title:  '全面预算平台',
    client: '某 A 股上市光伏制造龙头企业',
    role:   '项目经理 / 主管',
    period: '2021.04 — 2021.11',
    tags:   ['元年 C1', 'ERP 集成', 'BI 系统', '全面预算', '预实分析', '制造业'],
    overview:
      '构建统一的预算管理信息化平台，梳理预算管理体系，以预算编制为基础，以利润预算为主线，拉通业务部门，' +
      '实现业财连接，打通 ERP 系统中的数据，完善全面预算管理体系，有效提高整个公司的预算管控水平。',
    achievements: [
      '百万级项目，涉及下属 5 个板块、8 家公司、70+ 部门、300+ 用户',
      '涵盖生产、采购、销售、人力、财务、费用、固定资产预算等全模块',
      '打通 ERP 系统、费控系统、BI 系统，实现多版本管理、滚动预算、预实分析',
      '开展 20+ 场次培训，加强企业人员对全面预算管理的认知与落地执行',
    ]
  },
  'medical': {
    num:    '04',
    title:  'OTC 业财中台',
    client: '某外资高端连锁医疗集团（北京 / 上海 / 广州 / 深圳 / 天津 / 青岛 6 城院区）',
    role:   '项目经理 / 主管',
    period: '2022.01 — 2023.05',
    tags:   ['DeepFos', '会计引擎', '聚合支付', 'OTC', '业财中台', '医疗行业'],
    overview:
      '构建从订单到收款（Order To Cash）的业财管理中台，覆盖 9 个部门、100+ 用户。' +
      '实现账单电子化无纸化管理、远程聚合支付、业财数据链接，以及线上线下套餐全生命周期管理。',
    achievements: [
      '系统优化：账单电子化无纸化，节省每年近百万寄送费和打印费；会计引擎实现财务凭证自动生成',
      '流程优化：精简 OTC 各环节工作流程，梳理 40+ 份工作流规范',
      '组织优化：成立财务共享中心，将账单追账、交易对账、会计处理等工作系统化，减少约 100+ FTE',
      '体验优化：患者可通过手机远程完成账单签名和付款，无需到院',
    ]
  }
};

/* ── Navbar scroll state ─────────────────────────────── */
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', onScroll, { passive: true });

/* ── Section tracking ────────────────────────────────── */
const sections = [...document.querySelectorAll('.section')];
const dots     = [...document.querySelectorAll('.dot')];
const navLinks = [...document.querySelectorAll('.nav-links a')];

function onScroll() {
  navbar.classList.toggle('scrolled', window.scrollY > 30);

  let active = sections[0].id;
  sections.forEach(s => {
    if (s.getBoundingClientRect().top <= window.innerHeight * 0.45) active = s.id;
  });
  dots.forEach(d     => d.classList.toggle('active', d.dataset.target  === active));
  navLinks.forEach(a => a.classList.toggle('active', a.dataset.section === active));
}
onScroll();

dots.forEach(dot => {
  dot.addEventListener('click', () =>
    document.getElementById(dot.dataset.target).scrollIntoView({ behavior: 'smooth' })
  );
});

/* ── Reveal on scroll ────────────────────────────────── */
const observer = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add('visible');
      observer.unobserve(e.target);
    }
  });
}, { threshold: 0.1 });
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

/* ── Modal ───────────────────────────────────────────── */
const overlay      = document.getElementById('modal-overlay');
const modalContent = document.getElementById('modal-content');

document.querySelectorAll('.project-card:not(.project-soon)').forEach(card => {
  card.addEventListener('click', () => openModal(card.dataset.project));
});

function openModal(id) {
  const d = PROJECTS[id];
  if (!d) return;

  const tagsHtml = d.tags.map(t => `<span>${t}</span>`).join('');
  const listHtml = d.achievements.map(a => `<li>${a}</li>`).join('');
  const bodyHtml = d.overview.replace(/\n/g, '<br>');

  modalContent.innerHTML = `
    <span class="m-num">${d.num}</span>
    <h2 class="m-title">${d.title}</h2>
    <p class="m-client">${d.client}</p>
    <span class="m-meta">${d.role} &nbsp;·&nbsp; ${d.period}</span>
    <div class="m-tags">${tagsHtml}</div>
    <span class="m-label">项目概述</span>
    <p class="m-body">${bodyHtml}</p>
    <span class="m-label">主要成果</span>
    <ul class="m-list">${listHtml}</ul>
  `;

  overlay.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  overlay.classList.remove('open');
  document.body.style.overflow = '';
}

document.getElementById('modal-close').addEventListener('click', closeModal);
overlay.addEventListener('click', e => { if (e.target === overlay) closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
